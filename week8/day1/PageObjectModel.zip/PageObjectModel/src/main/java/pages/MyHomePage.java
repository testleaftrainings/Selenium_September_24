package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;

public class MyHomePage extends ProjectSpecificMethod{
	

	
	public void clickOnLeads() {
		getDriver().findElement(By.linkText("Leads")).click();
	}

}
