package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod{
	
	
	
	
	@When("Enter the username as {string}")
	public LoginPage enterUserName(String uName) throws IOException, InterruptedException {
		try {
			getDriver().findElement(By.id("username")).sendKeys(uName);
			reportStep("Username Enter Successfully", "pass");
		} catch (Exception e) {
			reportStep("Username not enter Successfully", "fail");
		}
		return this;
	}
	
	
	@And("Enter the password as {string}")
	public LoginPage enterPassWord(String passWord) throws IOException, InterruptedException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(passWord);
			reportStep("Password Enter Successfully", "pass");

		} catch (Exception e) {
			reportStep("Password not enter Successfully", "fail");

		}
return this;
	}
	
	@And("Click on Loginbutton")
	public WelcomePage clickLoginButton() throws IOException, InterruptedException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Click on Login Button Successfully", "pass");

		} catch (Exception e) {
			reportStep("Login button not clicked Successfully", "fail");

			
		}

		return new WelcomePage();
	}
	
	
	
}
