package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class WelcomePage extends ProjectSpecificMethod {

	@Then("Verify the title")
	public WelcomePage verify_the_title() {
	 String title = getDriver().getTitle();
	 
	 try {
		if(title.contains("Leaftaps")) {
			 System.out.println("Login is successfull");
			 test.info("Login is Successfull");
		 }else {
			 System.out.println("Login is not succesfull");
			 test.info("Login is not Successfull");
		 }
	} catch (Exception e) {
		test.info("Value is not read");
	}
	 return this;
	 
	}
	
	public MyHomePage clickOnCrmsfa() throws IOException, InterruptedException {
		try {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
			reportStep("Click on Crmsfa", "pass");
		} catch (Exception e) {
			reportStep("crmsfa is not clicked", "fail");
		}
return new MyHomePage();
	}
	
	
	public LoginPage clickOnLogOut() throws IOException, InterruptedException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Click on LogOut", "pass");
		} catch (Exception e) {
			reportStep("Logout button is not click", "fail");
		}
return new LoginPage();
	}
}

