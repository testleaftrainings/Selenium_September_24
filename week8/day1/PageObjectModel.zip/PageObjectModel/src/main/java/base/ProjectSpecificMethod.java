package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.IntegrationWithTC;


public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{

private static final ThreadLocal<RemoteWebDriver> tlDriver=new ThreadLocal<RemoteWebDriver>();

//step2
public static ExtentReports er;

//step5
public static ExtentTest test;


//step6
public String testName,testDescription,testAuthor,testCategory;

//step 1 
@BeforeSuite
public void startReport() {
			ExtentHtmlReporter wb=new ExtentHtmlReporter("./report/result.html");
			wb.setAppendExisting(true);
			 er=new ExtentReports();
			er.attachReporter(wb);
}

//step3
@AfterSuite
public void stopReport() {
	er.flush();
}

//step4
@BeforeClass
public void testDetails() {
	//step 7
	 test=er.createTest(testName, testDescription);
	test.assignAuthor(testAuthor);
	test.assignCategory(testCategory);

}

//step 9
public void reportStep(String testMessage,String status) throws IOException, InterruptedException {
	if(status.equalsIgnoreCase("pass")) {
		test.pass(testMessage, MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/ts"+takeSnap()+".png").build());
	}else if(status.equals("fail")) {
		test.fail(testMessage, MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/ts"+takeSnap()+".png").build());
	}
}

//takesanp

public int takeSnap() throws IOException {
	int random = (int)(Math.random()*99999);
	File scr = getDriver().getScreenshotAs(OutputType.FILE);
	File dst=new File("./Snaps/ts"+random+".png");
	FileUtils.copyFile(scr, dst);
	
	return random;
}
//ts345678.png,ts65456.png



	public void setDriver() {
		/*
		 * if(browser.equalsIgnoreCase("chrome")) { tlDriver.set(new ChromeDriver());
		 * }else if(browser.equalsIgnoreCase("edge")) { tlDriver.set(new EdgeDriver());
		 * }
		 */
		
		tlDriver.set(new ChromeDriver());
	}
	
	
	
	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}


public String data;

	@BeforeMethod
	public void preCondition() {
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}
	
	@DataProvider(name="getName",indices = 0)
	public String[][] fetchData() throws IOException{
		
		return IntegrationWithTC.readExcel(data);

	}




	
}
