package base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnSeleniumExceptionHandling {

	public static void main(String[] args) {
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		
	 try {
		driver.findElement(By.id("usernam")).sendKeys("DemoCsr");
	} catch (Exception e) {
		System.out.println(e);
		driver.findElement(By.name("USERNAME")).sendKeys("DemoSalesManager");
	}
		
		try {
			Thread.sleep(2000);
			driver.findElement(By.id("password")).sendKeys("crmsfa");
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		try {
			Thread.sleep(2000);
		WebElement	login = driver.findElement(By.className("decorativeSubmit"));
			login.click();
		} catch (Exception e) {
			System.out.println(e);
		}
		

		try {
			driver.findElement(By.partialLinkText("M/SFA")).click();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
