package base;

public class LearnExceptionHandling {
public static void main(String[] args) {
	int a=10;
	int b=5;
	
	try {
		System.out.println(a/b);
	} catch (Exception e) {
		System.out.println(e);
		System.out.println("its inside catch block "+a/2);
	}finally {
		System.out.println("Code working fine");
	}

	
	System.out.println("Done");
	
	
	
	//0.4225056025879663
	//0.17775472314212093
	//33068.49337892118
	//33086
	
	int random = (int)(Math.random()*99999);
	System.out.println(random);
}
}
