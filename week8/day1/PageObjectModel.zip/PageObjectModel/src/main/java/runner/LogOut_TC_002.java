package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class LogOut_TC_002 extends ProjectSpecificMethod{

	@BeforeTest
	public void setValues() {
testName="LogOut Page";
testDescription="Logout page for Leaftaps";
testAuthor="Ram";
testCategory="Sanity";
	}
	
	
	@Test
	public void login() throws IOException, InterruptedException {
		
		//loginpage -
		LoginPage lp=new LoginPage();
		lp.enterUserName("DemoSalesManager")
		.enterPassWord("crmsfa")
		.clickLoginButton()
		.clickOnLogOut();
		
	}
}
