package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

//POM -> pages==stepdef

@CucumberOptions(features="src/main/java/features/LoginPage.feature",
glue="pages",
monochrome = true,
publish = true)

public class CucumberRunner extends ProjectSpecificMethod{

	@BeforeTest
	public void setValues(){
		testAuthor="";
		testDescription="";
				testCategory="";
				testName="";
	}
	
	
	
	
	
	//copy the @DataProvider from AbstractTestNGCucumberTest
	//parallel=true
	// return super.scenarios();
	  @DataProvider(parallel=true)
	    public Object[][] scenarios() {
	        return super.scenarios();
	    }
}
