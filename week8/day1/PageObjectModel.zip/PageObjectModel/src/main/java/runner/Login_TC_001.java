package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class Login_TC_001 extends ProjectSpecificMethod{

	//step8
	@BeforeTest
	public void setValue() {
		data="Login";
		testAuthor="Dilip";
		testCategory="smoke";
		testDescription="Login with leaftaps application";
		testName="Login page";
	}
	
	
	
	
	@Test(dataProvider = "getName")
	public void login(String username,String passWord) throws IOException, InterruptedException {
		//loginpage -
		LoginPage lp=new LoginPage();
		lp.enterUserName(username)
		.enterPassWord(passWord)
		.clickLoginButton()
		.clickOnCrmsfa();
		
	}
}
