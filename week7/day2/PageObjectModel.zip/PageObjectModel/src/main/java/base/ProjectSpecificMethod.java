package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.IntegrationWithTC;


public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{

private static final ThreadLocal<RemoteWebDriver> tlDriver=new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver() {
		/*
		 * if(browser.equalsIgnoreCase("chrome")) { tlDriver.set(new ChromeDriver());
		 * }else if(browser.equalsIgnoreCase("edge")) { tlDriver.set(new EdgeDriver());
		 * }
		 */
		
		tlDriver.set(new ChromeDriver());
	}
	
	
	
	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}


public String data;

	@BeforeMethod
	public void preCondition() {
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}
	
	@DataProvider(name="getName")
	public String[][] fetchData() throws IOException{
		
		return IntegrationWithTC.readExcel(data);

	}




	
}
