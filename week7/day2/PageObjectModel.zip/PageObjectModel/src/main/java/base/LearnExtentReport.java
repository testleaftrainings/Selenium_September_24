package base;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {

		//step 1
		ExtentHtmlReporter wb=new ExtentHtmlReporter("./report/result.html");
		
		wb.setAppendExisting(true);
		
		//step 2
		ExtentReports er=new ExtentReports();
		
		//step 3 - combine step1 & step2
		er.attachReporter(wb);
		
		//step 4
		ExtentTest test=er.createTest("Login Page", "LeafTaps Application Login");
		test.assignAuthor("Dilip");
		test.assignCategory("Sanity");
		
		//step 5
		test.pass("EnterUserName", MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/ts.png").build());
		test.pass("EnterPassWord", MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/ts1.png").build());
		
		//step6
		er.flush();
		System.out.println("done");
	}

}
