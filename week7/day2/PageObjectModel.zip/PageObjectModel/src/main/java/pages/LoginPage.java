package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod{
	
	
	
	
	@When("Enter the username as {string}")
	public LoginPage enterUserName(String uName) {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		return this;
	}
	
	
	@And("Enter the password as {string}")
	public LoginPage enterPassWord(String passWord) {
		getDriver().findElement(By.id("password")).sendKeys(passWord);
return this;
	}
	
	@And("Click on Loginbutton")
	public WelcomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();

		return new WelcomePage();
	}
	
	
	
}
