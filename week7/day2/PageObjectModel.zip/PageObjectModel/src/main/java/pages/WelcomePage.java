package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class WelcomePage extends ProjectSpecificMethod {

	@Then("Verify the title")
	public WelcomePage verify_the_title() {
	 String title = getDriver().getTitle();
	 
	 if(title.contains("Leaftaps")) {
		 System.out.println("Login is successfull");
	 }else {
		 System.out.println("Login is not succesfull");
	 }
	 return this;
	 
	}
	
	public MyHomePage clickOnCrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
return new MyHomePage();
	}
	
	
	public LoginPage clickOnLogOut() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
return new LoginPage();
	}
}

