package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class Login_TC_001 extends ProjectSpecificMethod{

	@BeforeTest
	public void setValue() {
		data="Login";
	}
	
	
	
	
	@Test(dataProvider = "getName")
	public void login(String username,String passWord) {
		//loginpage -
		LoginPage lp=new LoginPage();
		lp.enterUserName(username)
		.enterPassWord(passWord)
		.clickLoginButton()
		.clickOnCrmsfa();
		
	}
}
