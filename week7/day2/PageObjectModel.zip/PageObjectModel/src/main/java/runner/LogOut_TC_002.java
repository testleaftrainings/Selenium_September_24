package runner;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class LogOut_TC_002 extends ProjectSpecificMethod{

	
	@Test
	public void login() {
		
		//loginpage -
		LoginPage lp=new LoginPage();
		lp.enterUserName("DemoSalesManager")
		.enterPassWord("crmsfa")
		.clickLoginButton()
		.clickOnLogOut();
		
	}
}
