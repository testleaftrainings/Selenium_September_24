package runner;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class LogOut_TC_002 extends ProjectSpecificMethod{

	
	@Test
	public void login() {
		
		System.out.println(driver);
		//loginpage -
		LoginPage lp=new LoginPage(driver);
		lp.enterUserName()
		.enterPassWord()
		.clickLoginButton()
		.clickOnLogOut();
		
	}
}
